#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

//Method to find initial values: Name, Number of Attributes and The number of House
void fileInOut(FILE *fp,char w[],int *atribute,int *house){
	fscanf(fp,"%s",w);
	fscanf(fp,"%d",atribute);
	fscanf(fp,"%d",house);
}
//Method to Create 2D Matrics of Different Size
double **createMatrix(double row, double col){
	double **matrix = (double **)malloc(row*sizeof(double*));
	int r;	
		for(r=0;r<row;r++){
			matrix[r]=(double *) malloc(col*sizeof(double));
		}
return matrix;
}
//Method to Read in Matrices from Train and Data and Store them
void InitMatrices(FILE *fp,char w[],int house,int atri,double **m,double **m2){
	int r,c;
	double hodl=0;
	double *hold=&hodl;
//Check if First Line is "train", Else Exit Code 1
	if(strcmp(w,"train")==0){
        	for(r=0;r<house;r++){
                	m[r]=(double *) malloc((atri+1)*sizeof(double));
			m2[r]=(double *) malloc((atri)*sizeof(double));  
		}
	        for(r=0;r<house;r++){
        	        for(c=0;c<=atri+1;c++){
				if(c==0){
				m[r][c]=1;
			}else if(c==atri+1){
				fscanf(fp,"%lf",hold);
				m2[r][0]=hodl;
			}else{
				fscanf(fp,"%lf",hold);
				m[r][c]=hodl;
			}                
		}
        }       
//Check If First line is "data" if its not Train , Then Store into Matrix                             
	}else if(strcmp(w,"data")==0){
		for(r=0;r<house;r++){
			for(c=0;c<atri;c++){
				if(c==0){
					m[r][c]=1;
				}else{
					fscanf(fp,"%lf",hold);
					m[r][c]=hodl;
 				}
			}
		}
//If not Train or Data, then ERROR, so Exit Code 1
	}else{
		exit(1);
	}
}
//Method to Input a Matrix to be Transposed and the Matrix to Store it In
void transpose(double **m,double **result,int row, int col){
	int r,c;	
	
	for(r=0;r<row;r++){
		for(c=0;c<col;c++){			
			result[c][r]=m[r][c];
		}
	}
}
//Method to multiply 2 Matrix, Need both Matrices Row and Columns
double **multiply(double **m,double **m2,int numRow,int numCol, int numRow2,int numCol2){
        int i,r,c;
	double **result=createMatrix(numRow,numCol2);
      
        for(r=0;r<numRow;r++){
	        for(c=0;c<numCol2;c++){
        	        for(i=0;i<numRow2;i++){
				 result[r][c]+=m2[i][c]*m[r][i]; 
                        }                                        		
		}
        }             
return result;
}
//Create the Identity Matrix, Need A Matrix to Store and The Row/Columns
void createIdentity(double **iden,int rowcol){
	int r,c;
	
	for(r=0;r<rowcol+1;r++){
		for(c=0;c<rowcol+1;c++){
			if(r==c){
				iden[r][c]=1;
			}else{
				iden[r][c]=0;
			}
		}
	}
}
//Row operation: Multiply Row by some number
void op1(double **matrix,double **iden,int numEle,int currentRow,double numberToMult){
	int c;	
	
	for(c=0;c<numEle;c++){
		matrix[currentRow][c]=matrix[currentRow][c]*numberToMult;
		iden[currentRow][c]=iden[currentRow][c]*numberToMult;
	}
}
//Row Operation: Adds multiple of Elements of One Row to another
//Same Calculation to be done on Identity Matrix
void op2(double **matrix,double **iden,int numEle,int row,int result,double numberToMult){
	int c;
	
	for(c=0;c<numEle;c++){
		matrix[result][c]=(matrix[row][c]*numberToMult)+matrix[result][c];
		iden[result][c]=((iden[row][c]*numberToMult))+iden[result][c];
	}
}
//Invert A Given Matrix, Need The set Identity Matrix and Row/Columns
void inverse(double **tbInv,double **iden,int rowcol){
	int r=0,c=0, x=0;
//Turn Matrix into Upper Triangular Matrix
	for(r=0;r<rowcol;r++){
		if(tbInv[r][c]!=1){
			op1(tbInv,iden,rowcol,r,(1/tbInv[r][c]));		
		}
	for(x=r+1;x<rowcol;x++){
		if(tbInv[x][c]!=0){
			op2(tbInv,iden,rowcol,r,x,-(tbInv[x][c]/tbInv[r][c]));
			}	
	}		
		c++;
	}
//Upper Trangular Matrix -->Final Inversed Matrix
	c=rowcol-1;
        
	for(r=c;r>0;r--){            
                for(x=r-1;x>=0;x--){
                         if(tbInv[x][c]!=0){
        	                 op2(tbInv,iden,rowcol,r,x,-(tbInv[x][c]/tbInv[r][c]));
                         }
                }
             	c--;
 	}
                
}

int main (int argc, char**argv){
//Read Train File Begins Here
	FILE *fp=fopen(argv[1],"r");
	char Xword[100];
	int Xatri=0;
	int Xhouse=0;
	fileInOut(fp,Xword,&Xatri,&Xhouse);
//Read Data File Begins Here
FILE *fpd=fopen(argv[2],"r");
        char word2[100];
        int numAt2=0;
        int numhouse2=0;
        fileInOut(fpd,word2,&numAt2,&numhouse2);
//The insane amount of useless variables makes it easier to keep track
//of Rows and Columns of Each Matrix  --- For me
	int columns=Xatri+1;
	double **matrix=(double **)malloc((sizeof(double*)*(Xhouse)));
	int Xrow=Xhouse,Xcol=columns;
	double **matrix2=(double **)malloc((sizeof(double*)*(Xhouse)));
	int Yrow=Xhouse,Ycol=1;
	double **transMatrix=createMatrix(columns,Xhouse);
	int Trow=columns,Tcol=Xhouse;
	double **multMatrix=createMatrix(columns,columns);
	double **idenMatrix=createMatrix(columns,columns);
//Method Call to Store Train File
	InitMatrices(fp,Xword,Xhouse,Xatri,matrix,matrix2);
//Close Train File
	fclose(fp);
//X Transpose
	transpose(matrix,transMatrix,Xhouse,columns); 
//X Transpse Times X Matrix	
	multMatrix = multiply(transMatrix,matrix,Trow,Tcol,Xrow,Xcol);
//Identity Matrix Create
	createIdentity(idenMatrix,Xatri);
//Invert multMatrix or X trans times X Matrix
	inverse(multMatrix,idenMatrix,columns);
	int Inrow=columns;
	int Irow=columns,Icol=columns;
//XT Times Y Matrix
	double **rm=createMatrix(columns,Ycol);
	rm = multiply(transMatrix,matrix2,Trow,Tcol,Yrow,Ycol);
	int Rrow=Trow,Rcol=Ycol;
//Weight = (XTX)' (XTY)
	double **weight=createMatrix(Inrow,Rcol);
	int Wrow=Inrow,Wcol=Rcol;
	weight=multiply(idenMatrix,rm,Irow,Icol,Rrow,Rcol);
//DATA MAtrix With the Weight Column
	int finalCol=numAt2+1;
	double **dataMatrix=createMatrix(numhouse2,finalCol);
//Method Call to Store Data File
	InitMatrices(fpd,word2,numhouse2,finalCol,dataMatrix,NULL);
//Creation of Result Matrix to Store Calculattion of Y'
	double **finalCost= createMatrix(numhouse2,Wcol);
	finalCost = multiply(dataMatrix,weight,numhouse2,finalCol,Wrow,Wcol);
	int Frow=numhouse2,Fcol=Wcol;
//Print the Y'
	int i11,j11;
	for(i11=0;i11<Frow;i11++){
        	for(j11=0;j11<Fcol;j11++){
                	printf("%.lf",finalCost[i11][j11]);
			if(j11+1!=Fcol){
                	printf(" ");
			}
		}
		if(i11+1!=Frow){
		printf("\n");
		}
	}


//Free Matrices and Close File
	fclose(fpd);
	free(matrix);	
	free(matrix2);
	free(transMatrix);
	free(multMatrix);
	free(idenMatrix);
//Learn Succesfully Completed
	exit(0);
}
